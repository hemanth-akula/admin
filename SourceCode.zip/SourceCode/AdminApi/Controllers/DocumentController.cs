﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Admin.Intefaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AdminApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DocumentController : ControllerBase
    {

        private readonly ILogger<DocumentController> _logger;

        private readonly IDocumentBAL _document;

        public DocumentController(ILogger<DocumentController> logger, IDocumentBAL document)
        {
            _logger = logger;
            _document = document;
        }
        // GET: api/Document
        [HttpGet]
        public string Get()
        {
            var response = JsonConvert.SerializeObject(_document.GetAllDocuments());
            return response;
        }

        
    }
}
