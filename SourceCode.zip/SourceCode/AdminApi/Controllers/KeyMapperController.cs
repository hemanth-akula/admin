﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Admin.Entity;
using Admin.Intefaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AdminApi.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class KeyMapperController : ControllerBase
    {

        private readonly ILogger<KeyMapperController> _logger;

        private readonly IKeyWordBAL _keyWord;

        public KeyMapperController(ILogger<KeyMapperController> logger, IKeyWordBAL keyWordBAL)
        {
            _logger = logger;
            _keyWord = keyWordBAL; 
        }

        [HttpGet]
        public string Get()
        {

            var response =JsonConvert.SerializeObject(_keyWord.GetAllKeyWords());
            return response;
        }


        [HttpGet("name")]
        
        public string Get(string name)
        {

            var response = JsonConvert.SerializeObject(_keyWord.GetKeyWordByName(name));
            return response;
        }

        [HttpPost]
        [Route("Update")]
        public bool Update(UpdateKeyWordMapping updateKeyWordMapping)
        {

            return _keyWord.UpdateKeyWordMapping(updateKeyWordMapping.id, updateKeyWordMapping.NewIds, updateKeyWordMapping.RemovedIds);
        }

        [HttpPost]
        [Route("Add")]
        public bool Add(KeyWord keyWord)
        {

            return _keyWord.AddNewKeyword(keyWord.Name,keyWord.DocumentIds);
            
        }

        [HttpDelete]

        [Route("delete/{id}")]
        public bool Delete(string id)
        {
            return _keyWord.DeleteKeyword(id);
        }
    }
}
