using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Admin;
using Admin.BussinessLayer;
using Admin.DataAccess;
using Admin.Intefaces;
using Admin.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace AdminApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddOptions();
            

            services.Configure<AdminConfiguration>(Configuration.GetSection("ConnectionStrings"));
            services.AddTransient<ISqlConnectionFactory, SqlConnectionFactory>();
            services.AddTransient<IKeyWordBAL, KeyWordBAL>();
            services.AddTransient<IKeyWordDAL, KeyWordDAL>();
            services.AddTransient<IKeyWordRepository, KeyWordRepository>();

            services.AddTransient<IDocumentBAL, DocumentBAL>();
            services.AddTransient<IDocumentDAL, DocumentDAL>();
            services.AddTransient<IDocumentRepository, DocumentRepository>();
            services.AddControllers(options =>
            {
                options.RespectBrowserAcceptHeader = true; 
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors(x => x
                .AllowAnyMethod()
                .AllowAnyHeader()
                .SetIsOriginAllowed(origin => true) 
                .AllowCredentials()); 
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
