

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Documents] (
    [Id]   INT   IDENTITY (1, 1) PRIMARY KEY,
    [NAME] NVARCHAR (50) Not NULL,
    [Url]  NCHAR (10)    Not NULL
);


CREATE TABLE [dbo].[KeyWords] (
    [Id]   INT  IDENTITY (1, 1) PRIMARY KEY,
    [Name] NVARCHAR (50) NOT NULL
);

CREATE INDEX idx_Name
ON KeyWords (Name);

CREATE TABLE [dbo].[Keywords_Document_Mapping] (
    [Id]          INT IDENTITY (1, 1) NOT NULL PRIMARY KEY, 
    [Keyword_id]  INT NOT NULL,
    [Document_id] INT NOT NULL,
	CONSTRAINT FK_KeyWord FOREIGN KEY (KeyWord_Id) REFERENCES KeyWords(id),
	CONSTRAINT FK_Dcoument FOREIGN KEY (Document_id) REFERENCES Documents(id)
	
);
CREATE INDEX idx_keywordMapping
ON Keywords_Document_Mapping (Keyword_id);

SET IDENTITY_INSERT [dbo].[Documents] ON
INSERT INTO [dbo].[Documents] ([Id], [NAME], [Url]) VALUES (1, N'Doc1', N'url1      ')
INSERT INTO [dbo].[Documents] ([Id], [NAME], [Url]) VALUES (2, N'Doc2', N'url2      ')
INSERT INTO [dbo].[Documents] ([Id], [NAME], [Url]) VALUES (3, N'Doc3', N'Url3      ')
INSERT INTO [dbo].[Documents] ([Id], [NAME], [Url]) VALUES (5, N'Doc4', N'Url4      ')
SET IDENTITY_INSERT [dbo].[Documents] OFF







