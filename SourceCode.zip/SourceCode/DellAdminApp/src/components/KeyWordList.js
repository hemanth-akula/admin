import React from 'react'
import {ListGroup,ListGroupItem,Button} from 'react-bootstrap'

export const KeyWordList = (props) => {
 
    let onShowDetailsClick=(selectedRecord)=>{
        props.showPopUp(true);
        props.onClickSelectedKeyWord(selectedRecord)
    }

    return (
        
        <ListGroup className ="d-flex">
        {props.keywords.length>0 && props.keywords.map(x=> <ListGroupItem>
    <strong >
{x.Name}
</strong>
<div style={{position:"absolute",right:"1%",top:"10%"}}>
<Button className="btn btn-warning mr-1" style={{marginRight:"10px"}} onClick={()=>onShowDetailsClick(x)}>View/Edit</Button>
<Button style={{backgroundColor:"red",borderWidth:"0px",right:"0px"}} onClick={()=>props.onDeleteKeywordClick(x)}>Delete</Button>
</div>
</ListGroupItem>

        )
       
        }
        {props.keywords.length==0 && <label style={{width:"100%",textAlign:"center",fontSize:"x-large"}}>No Records Found</label>}
        </ListGroup>
    )
}
