import React, { Component } from 'react'
import {KeyWordList} from './KeyWordList';
import {Navbar,Container,NavbarBrand,Button,NavItem} from 'react-bootstrap';
import Popup from './Popup';
import {getKeyWords,AddNewKeyword,UpdateMapping,DeleteMapping} from '../services/KeyWordService';
import {getDocuments} from '../services/DocumentService';
export default class Home extends Component {
    
    constructor(props) {
        super(props);
        this.state={
            isPopUpVisibe:false,
            keywords:[],
            FilteredKeyWords:[],
            documents:[],
            unmappedDocs:[],
            mappedDocs:[],
            isAdd:false,
            SearchText:'',
            newSelectedDocForMApping:[],
            newSelectedDocForRemovin:[],
           selectedKeyWord:{Id:'',Name:'',DocumentIds:[]}
       }
    }

    componentDidMount(){
        const keywordRepsone =  getKeyWords();
        
        keywordRepsone.then(data=>{
            
            this.setState({keywords:data})
        })
        const documents =  getDocuments();
        getDocuments().then(data=>{
            this.setState({documents:data})
        })
        
    }
  showPopUp =(isvisible)=>{
  this.setState({isPopUpVisibe:isvisible})
 };
 onTextChange=(event)=>{
    this.setState({selectedKeyWord:{...this.state.selectedRecord,Name:event.target.value}})
 }

 onSearchTextChange=(event)=>{
    this.setState({SearchText:event.target.value})
 }
 onAddKeyWordClick(){

    this.setState({unmappedDocs:this.state.documents}) ;
    this.setState({mappedDocs:[]});
    this.setState({isAdd:true}) ;
    this.setState({selectedKeyWord:{Id:'',Name:'',DocumentIds:[]}})
    this.showPopUp(true);
 }

 onClickSelectedKeyWord=(selectedRecord)=>{
    this.setState({selectedKeyWord:selectedRecord})
    this.setState({mappedDocs:this.state.documents.filter(x=>selectedRecord.DocumentIds.includes(x.Id))})
    this.setState({unmappedDocs:this.state.documents.filter(x=>!selectedRecord.DocumentIds.includes(x.Id))})
 }

 RemovingMapping=()=>{
     
    this.state.mappedDocs.forEach(element => {
                   if(this.state.newSelectedDocForRemovin.includes(element.Id.toString()))
                   {
                      this.state.unmappedDocs.push(element)
                      this.state.mappedDocs=this.state.mappedDocs.filter(x=>x.Id != element.Id)
                   }
               });
    this.setState({mappedDocs:this.state.mappedDocs})
    this.setState({unmappedDocs:this.state.unmappedDocs}) ;
 };

 AddNewMapping =()=>{
    this.state.unmappedDocs.forEach(element => {
                   if(this.state.newSelectedDocForMApping.includes(element.Id.toString()))
                   {
                      this.state.unmappedDocs = this.state.unmappedDocs.filter(x=>x.Id != element.Id)
                      this.state.mappedDocs.push(element)
                   }
               });
    this.setState({mappedDocs:this.state.mappedDocs})
    this.setState({unmappedDocs:this.state.unmappedDocs}) ;
 };
 onMappedDocsChange=(e)=>{
    let RemovedDocIds=Array.from(e.target.selectedOptions, option => option.value);
    this.setState({newSelectedDocForRemovin:RemovedDocIds});
  };

 
onUnMappedDocsChange=(e)=>{
        let AddedDocIds = Array.from(e.target.selectedOptions, option => option.value);
    this.setState({newSelectedDocForMApping:AddedDocIds});
 }
 onSearchButtonClick=()=>{
    
this.setState({FilteredKeyWords:this.state.keywords.filter(x=>x.Name.includes(this.state.SearchText))})
 }

 onDeleteKeywordClick=(selectedRecord)=>{
     DeleteMapping(selectedRecord.Id).then(()=>{
        this.setState({keywords:this.state.keywords.filter(x=>x.Id != selectedRecord.Id)})
     }
         
     )
 }
 onSaveClick=()=>{
      if(this.state.isAdd)
      {
        this.setState({isAdd:false}) ;
      var newKeyword ={};
      newKeyword.Id=1;
      newKeyword.Name= this.state.selectedKeyWord.Name
      newKeyword.DocumentIds=this.state.mappedDocs.map(x=>x.Id);
     AddNewKeyword(newKeyword).
     then(()=>{
         this.showPopUp(false);
         alert('SuccessFully added');
         const keywordRepsone =  getKeyWords();
         keywordRepsone.then(data=>{
             
             this.setState({keywords:data})
         })
     })}
     else{
         var updatedKeywordMapping={}
         var mappedDocids = this.state.mappedDocs.map(x=>x.Id);
         updatedKeywordMapping.id = this.state.selectedKeyWord.Id
         
         updatedKeywordMapping.newIds= mappedDocids.filter(x=>!this.state.selectedKeyWord.DocumentIds.includes(x))
                                           
         updatedKeywordMapping.RemovedIds= this.state.selectedKeyWord.DocumentIds.filter(x=>!mappedDocids.includes(x))
         UpdateMapping(updatedKeywordMapping).then(()=>{
            this.showPopUp(false);
            alert('SuccessFully Updated');
            const keywordRepsone =  getKeyWords();
            keywordRepsone.then(data=>{
                
                this.setState({keywords:data})
            })
         });

 }
}
 
    render() {
        return (
            <div>
        <Navbar className="navbar navbar-dark bg-dark">
            <Container>
            <Button onClick={()=>this.onAddKeyWordClick()}> Add</Button>
           
            
            <NavItem >
            <div class="form-inline">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" onChange={(e)=>this.onSearchTextChange(e)}/>
            {/* <Button class="btn btn-outline-success my-2 my-sm-0" type="submit" onClick={()=>this.onSearchButtonClick()} >Search</Button> */}
            </div>
            </NavItem>
              </Container>
        </Navbar>
        
        <KeyWordList keywords= {this.state.keywords.filter(x=>x.Name.includes(this.state.SearchText))} showPopUp={this.showPopUp} 
        onDeleteKeywordClick= {this.onDeleteKeywordClick}
        onClickSelectedKeyWord={this.onClickSelectedKeyWord}></KeyWordList>

        <Popup  selectedKeyWord={this.state.selectedKeyWord} onTextChange={this.onTextChange}
        onSaveClick={this.onSaveClick}
        show={this.state.isPopUpVisibe} onHide={()=>this.showPopUp(false)} unmappedDocs={this.state.unmappedDocs}
              mappedDocs={this.state.mappedDocs}  RemovingMapping={this.RemovingMapping} AddNewMapping ={this.AddNewMapping }
              onMappedDocsChange={this.onMappedDocsChange} onUnMappedDocsChange={this.onUnMappedDocsChange}></Popup>
            </div>
        )
    }
}
