import Home from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div style={{maxWidth:"40rem",margin:"4rem auto"}}>
     <Home  />
    </div>
  );
}

export default App;
