import React from 'react'

export const  getKeyWords =()=>{
        return fetch('http://localhost:53575/KeyMapper')
        .then(data =>data.json())
    }
export const AddNewKeyword=(body)=>{
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };
    return fetch('http://localhost:53575/KeyMapper/Add',requestOptions)
    .then(data =>data.json())
}

export const UpdateMapping=(body)=>{
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    };
    return fetch('http://localhost:53575/KeyMapper/update',requestOptions)
    .then(data =>data.json())
}

export const DeleteMapping=(keyWordId)=>{
    const requestOptions = {
        method: 'Delete',
        headers: { 'Content-Type': 'application/json' }
    };
    return fetch('http://localhost:53575/KeyMapper/delete/'+keyWordId,requestOptions)
    .then(data =>data.json())
}

