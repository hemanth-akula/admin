import React from 'react'

export const  getDocuments =()=>{
        
        return fetch('http://localhost:53575/api/document')
        .then(data =>data.json())
    }
